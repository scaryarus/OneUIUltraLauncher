package com.example.oneuiultra

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val SamsungBlue = Color(0xFF3977E8)
private val LightBackground = Color(0xFFF3F5FA)
private val DarkBackground = Color(0xFF10131A)

data class AppEntry(
    val label: String,
    val packageName: String,
    val icon: android.graphics.drawable.Drawable,
    val isGame: Boolean
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OneUiUltraApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OneUiUltraApp() {
    val context = LocalContext.current
    val pm = context.packageManager
    var page by remember { mutableStateOf("home") }
    var search by remember { mutableStateOf("") }
    var dark by remember { mutableStateOf(false) }

    val apps = remember {
        val launchIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        pm.queryIntentActivities(launchIntent, 0)
            .mapNotNull { info ->
                val appInfo = info.activityInfo.applicationInfo
                if (appInfo.packageName == context.packageName) null else AppEntry(
                    label = info.loadLabel(pm).toString(),
                    packageName = appInfo.packageName,
                    icon = info.loadIcon(pm),
                    isGame = appInfo.category == ApplicationInfo.CATEGORY_GAME
                )
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    val background = if (dark) DarkBackground else LightBackground
    val card = if (dark) Color(0xFF1C2230) else Color.White
    val foreground = if (dark) Color(0xFFF5F7FC) else Color(0xFF111827)

    MaterialTheme(
        colorScheme = if (dark) darkColorScheme(primary = Color(0xFF8DB4FF), background = background, surface = card)
        else lightColorScheme(primary = SamsungBlue, background = background, surface = card)
    ) {
        Scaffold(
            containerColor = background,
            bottomBar = {
                NavigationBar(containerColor = card) {
                    NavigationBarItem(page == "home", { page = "home" }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Главная") })
                    NavigationBarItem(page == "apps", { page = "apps" }, icon = { Icon(Icons.Default.GridView, null) }, label = { Text("Приложения") })
                    NavigationBarItem(page == "games", { page = "games" }, icon = { Icon(Icons.Default.SportsEsports, null) }, label = { Text("Игры") })
                    NavigationBarItem(page == "settings", { page = "settings" }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Настройки") })
                }
            }
        ) { padding ->
            AnimatedContent(targetState = page, label = "main_pages", modifier = Modifier.padding(padding)) { selected ->
                when (selected) {
                    "home" -> HomePage(apps, foreground, card, dark, onOpen = { launchApp(context, it.packageName) }, onApps = { page = "apps" }, onGames = { page = "games" })
                    "apps" -> AppPage(apps.filter { it.label.contains(search, ignoreCase = true) }, search, { search = it }, foreground, card) { launchApp(context, it.packageName) }
                    "games" -> GamesPage(apps.filter { it.isGame }, foreground, card) { launchApp(context, it.packageName) }
                    else -> SettingsPage(dark, { dark = it }, foreground, card)
                }
            }
        }
    }
}

private fun launchApp(context: android.content.Context, packageName: String) {
    val intent = context.packageManager.getLaunchIntentForPackage(packageName)
    if (intent != null) context.startActivity(intent)
}

@Composable
fun HomePage(apps: List<AppEntry>, fg: Color, card: Color, dark: Boolean, onOpen: (AppEntry) -> Unit, onApps: () -> Unit, onGames: () -> Unit) {
    val date = remember { SimpleDateFormat("EEEE, d MMMM", Locale("ru")).format(Date()).replaceFirstChar { it.uppercase() } }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp)) {
        Text("Доброе время суток", color = fg.copy(alpha = .65f), fontSize = 15.sp)
        Spacer(Modifier.height(4.dp))
        Text("Главная", color = fg, fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Card(shape = RoundedCornerShape(30.dp), colors = CardDefaults.cardColors(containerColor = card), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(22.dp)) {
                Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()), fontSize = 54.sp, fontWeight = FontWeight.Light, color = fg)
                Text(date, color = fg.copy(alpha = .65f), fontSize = 15.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ActionTile("Все приложения", Icons.Default.Apps, card, fg, Modifier.weight(1f), onApps)
            ActionTile("Игровой центр", Icons.Default.SportsEsports, card, fg, Modifier.weight(1f), onGames)
        }
        Spacer(Modifier.height(22.dp))
        Text("Избранные приложения", color = fg, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))
        val favorites = apps.take(8)
        LazyVerticalGrid(columns = GridCells.Fixed(4), verticalArrangement = Arrangement.spacedBy(14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(favorites) { app -> AppIcon(app, fg, onOpen) }
        }
    }
}

@Composable
fun ActionTile(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, card: Color, fg: Color, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier = modifier.height(112.dp).clickable { onClick() }, shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = card)) {
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(icon, null, tint = SamsungBlue, modifier = Modifier.size(27.dp))
            Text(title, color = fg, fontWeight = FontWeight.Medium, fontSize = 14.sp)
        }
    }
}

@Composable
fun AppPage(apps: List<AppEntry>, search: String, onSearch: (String) -> Unit, fg: Color, card: Color, onOpen: (AppEntry) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 16.dp)) {
        Text("Приложения", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = fg)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(value = search, onValueChange = onSearch, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(22.dp), placeholder = { Text("Поиск приложений") }, leadingIcon = { Icon(Icons.Default.Search, null) })
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(4), verticalArrangement = Arrangement.spacedBy(18.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(apps) { app -> AppIcon(app, fg, onOpen) }
        }
    }
}

@Composable
fun GamesPage(games: List<AppEntry>, fg: Color, card: Color, onOpen: (AppEntry) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Игровой центр", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = fg)
        Spacer(Modifier.height(6.dp))
        Text("Твои установленные игры", color = fg.copy(alpha = .65f))
        Spacer(Modifier.height(18.dp))
        Card(shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = card), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Icon(Icons.Default.Bolt, null, tint = SamsungBlue, modifier = Modifier.size(30.dp))
                Spacer(Modifier.height(8.dp))
                Text("Игровой режим", fontWeight = FontWeight.SemiBold, color = fg, fontSize = 18.sp)
                Text("Быстрый доступ к играм и настройкам. Системные ограничения Android сохраняются.", color = fg.copy(alpha = .65f), fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(18.dp))
        if (games.isEmpty()) {
            Text("Автоматически отмеченных игр пока нет. Открой вкладку «Приложения», чтобы найти игру.", color = fg.copy(alpha = .7f))
        } else {
            LazyVerticalGrid(columns = GridCells.Fixed(3), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                items(games) { app -> AppIcon(app, fg, onOpen) }
            }
        }
    }
}

@Composable
fun SettingsPage(dark: Boolean, onDark: (Boolean) -> Unit, fg: Color, card: Color) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Настройки", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = fg)
        Spacer(Modifier.height(18.dp))
        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = card)) {
            Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Тёмная тема", color = fg, fontWeight = FontWeight.SemiBold)
                    Text("Изменить оформление приложения", color = fg.copy(alpha = .6f), fontSize = 12.sp)
                }
                Switch(checked = dark, onCheckedChange = onDark)
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = card)) {
            Column(Modifier.padding(18.dp)) {
                Text("One UI Ultra", color = fg, fontWeight = FontWeight.SemiBold)
                Text("Первая тестовая версия · Android 8.0+", color = fg.copy(alpha = .6f), fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun AppIcon(app: AppEntry, fg: Color, onOpen: (AppEntry) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onOpen(app) }.padding(4.dp)) {
        androidx.compose.ui.viewinterop.AndroidView(
            factory = { android.widget.ImageView(it).apply { scaleType = android.widget.ImageView.ScaleType.FIT_CENTER; setImageDrawable(app.icon) } },
            modifier = Modifier.size(48.dp)
        )
        Spacer(Modifier.height(5.dp))
        Text(app.label, color = fg, fontSize = 11.sp, maxLines = 1)
    }
}
